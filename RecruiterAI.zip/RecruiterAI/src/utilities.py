import http
import bcrypt
from flask import jsonify, Blueprint, request, session
from langchain_text_splitters import CharacterTextSplitter
from langchain_community.vectorstores import FAISS
from langchain.memory import ConversationBufferMemory
from langchain.chains import ConversationalRetrievalChain
from variable_loader import embeddings, llm_global
from io import BytesIO
from openpyxl.styles import Font
import openpyxl
import os
import uuid
import tempfile
from pypdf import PdfReader
from pypdf.errors import PdfReadError
import pikepdf
import pyodbc

utilities_bp = Blueprint('utilities_bp', __name__)

def repair_pdf_with_pikepdf(pdf_path_or_obj):
    """
    Attempt to open (and thereby repair) the PDF with pikepdf and
    return a path to a temporary repaired file. If unsuccessful, return None.
    """
    try:
        # Create a temporary file for the repaired PDF
        temp_file_path = os.path.join(tempfile.gettempdir(), f"repaired_{uuid.uuid4()}.pdf")

        # pikepdf can open either a filename or a file-like object
        with pikepdf.Pdf.open(pdf_path_or_obj) as pdf:
            pdf.save(temp_file_path)

        return temp_file_path
    except pikepdf.PdfError as e:
        print(f"[pikepdf] Repair failed: {e}")
        return None


def extract_text_from_pdf(pdf_path_or_obj):
    """
    Extracts text from a single PDF (filename or file-like object).
    Tries pypdf first; if it fails, attempts repair with pikepdf, then retries.
    """
    try:
        # Attempt to read normally with pypdf
        reader = PdfReader(pdf_path_or_obj,strict=False)
        return "\n".join(page.extract_text() or "" for page in reader.pages)
    except PdfReadError as e:
        print(f"[pypdf] Initial read error: {e}")
        # Attempt to repair using pikepdf
        repaired_file_path = repair_pdf_with_pikepdf(pdf_path_or_obj)
        if repaired_file_path:
            try:
                # Retry with the repaired PDF
                reader = PdfReader(repaired_file_path,strict=False)
                text = "\n".join(page.extract_text() or "" for page in reader.pages)
                return text
            except PdfReadError as e2:
                print(f"[pypdf] Failed to read even after repair: {e2}")
            finally:
                # Clean up the repaired temp file
                if os.path.exists(repaired_file_path):
                    os.remove(repaired_file_path)
        # If repair fails, return an empty string or an error message
        return "[ERROR] Could not repair this PDF."
    except Exception as e:
        # Catch-all for unexpected errors (IOError, etc.)
        print(f"[pypdf] Unexpected error: {e}")
        return f"[ERROR] {e}"


def get_pdf_text(pdf_docs):
    """
    Takes a list of PDF file-like objects or file paths (pdf_docs)
    and returns their text concatenated.
    """
    all_text = ""
    for pdf_doc in pdf_docs:
        # pdf_doc can be either a file path string or an open file object
        # If you're certain they are file paths, just pass them directly
        extracted_text = extract_text_from_pdf(pdf_doc)
        all_text += extracted_text + "\n"
    return all_text


def get_text_chunks(text):
    text_splitter = CharacterTextSplitter(
        separator="\n",
        chunk_size=20000,
        chunk_overlap=2000,
        length_function=len)
    chunks = text_splitter.split_text(text)
    return chunks

def get_vectorstore(text_chunks):
    vectorstore = FAISS.from_texts(text_chunks, embedding=embeddings)
    return vectorstore

def get_conversation_chain(vectorstore):
    memory = ConversationBufferMemory(memory_key='chat_history', return_messages=True)
    conversation_chain = ConversationalRetrievalChain.from_llm(
        llm=llm_global,
        retriever=vectorstore.as_retriever(),
        memory=memory)
    return conversation_chain

def create_excel(data_list):
    # Create a new workbook and select the active sheet
    workbook = openpyxl.Workbook()
    sheet = workbook.active

    # Define headers
    headers = ['Employee Name', 'Score', 'Email-ID', 'Contact No.', 'Score Given to Skills', 'Experience']
    sheet.append(headers)

    # Apply bold font to the header cells
    bold_font = Font(bold=True)
    for cell in sheet[1]:
        cell.font = bold_font

    # Add data rows
    for item in data_list:
        col1, col2, col3, col4, col5, col6 = item
        sheet.append([col1, col2, col3, col4, col5, col6])

    # Save the workbook to a BytesIO object
    output = BytesIO()
    workbook.save(output)
    output.seek(0)
    
    return output

def currency_converter_usd_to_inr(amount):
    conn = http.client.HTTPSConnection("anyapi.io")
    url = f"/api/v1/exchange/convert?base=USD&to=INR&amount={amount}&apiKey=21f00gu29to1r36s3241p6dn4omvcbaodhk3p8s0018immmr5amcng"
    try:
        conn.request("GET", url)
        res = conn.getresponse()
        if res.status == 200:  # Check if the request was successful
            data = res.read()
        else:
            print(f"Error: {res.status} {res.reason}")
        return data.decode("utf-8")
    except Exception as e:
        print(f"An error occurred: {e}")
    finally:
        conn.close()

