from flask import Blueprint, request, jsonify
from src.utilities import get_pdf_text
from src.gpt_utilities import get_completion,get_result_from_omni
import json,ast

cv_analyzer_bp = Blueprint('cv_analyzer_bp', __name__)

@cv_analyzer_bp.route('/get_skills_and_weightages', methods=['POST'])
def get_skills_and_weightages():
    print("Getting skills")
    pdf_file_JD=request.files.getlist('pdf_file_JD')
    global combined_text_JD
    combined_text_JD=get_pdf_text(pdf_file_JD)
    system_message = '''Identify the technical skills and their weightages from the given job description. Provide the final output as an array formatted as [["Skill", "Weightage%"],["Experience in HR management", "10%"],["Experience in HR systems implementation", "15%"],["Proficiency in HR tools and data analytics", "15%"],["Knowledge of SuccessFactors or similar HR platforms", "15%"],["Team management experience", "10%"],["Communication and interpersonal skills", "10%"],["Project management skills", "10%"],["Analytical and problem-solving skills", "15%"]]. Ensure the total weightage should be strictly 100 percentage. Output only the array, without any additional text.'''
    result=get_completion(system_message,combined_text_JD)
    return jsonify(result)

@cv_analyzer_bp.route('/generate_ranking', methods=['POST'])
def generate_ranking():
    global combined_text_CV
    try:
        pdf_files_CV=request.files.getlist('pdf_files_CV')
        combined_text_CV=get_pdf_text(pdf_files_CV)
        skills=request.form['skills'].split("@")
        weightages=request.form['weightages'].split(",")
        skiwei=""
        for i in range(len(skills)):
            skiwei+="\n"+". ["+skills[i]+"]: ["+weightages[i]+"]"

        system_message="""
        Develop an advanced ranking system to evaluate CVs against a specific set of skills and weightages provided. The skills and weightages are listed as follows: [Skill Weightages].

        Consider the following factors for ranking:

        1. **Evaluation Criteria**:
        - **Skills and Weightages**: Compare the CV's skills to the list of skills provided. Evaluate each CV based solely on how well it matches the skills and weightages provided.
        - **Experience and Certifications**: If the CV mentions relevant experience or certifications for the provided skills, use this information to calculate the score.
        
        2. **Score Calculation**:
        - For each provided skill in the list, calculate the score as follows:
            - **Score for [Skill X]** = ([Weightage % for Skill X] * [Relevance of Skill X in CV]) + ([Experience Weightage] * [Years of Experience in Skill X in CV]) + ([Certification Weightage for Skill X] * [Relevance of Certification in Skill X in CV])
        - **Relevance**: If a skill from the provided list is not present in the CV, it should be scored as 0.
        - **Experience Weightage**: A constant representing the importance of experience in the calculation.
        - **Certification Weightage for Skill X**: A constant representing the importance of certifications for Skill X.
        - **Relevance of Certification**: Binary (1 if the certification is relevant, 0 if not).
        - **Years of Experience**: The number of years of experience in the relevant skill mentioned in the CV.

        3. **Sum of scores**:
        - Calculate the total score by summing the scores for all provided skills to get the overall score out of 100% for a CV.

        4. **Sorting**: Sort CVs in descending order of their Sum of scores, with the highest score at the top.

        Provide the output strictly as a list of list of values with the following key names and formats:
        - Candidate Name
        - Sum of scores '/100'
        - Email ID
        - Contact Number
        - String of each provided skill name and its calculated score based on the provided skill list. Example: 'Skill 1 5, Skill 2 10'
        - Candidate experience in years

        Ensure that the scoring is exclusively based on the provided skills and weightages. Do not consider any other skills mentioned in the CV. Do not include additional formatting, indentation, or unnecessary information. Do not provide any code, template, intermediate steps, or explanation. Strictly provide the final results as a list of list of values and nothing else.
        """
        system_message = system_message.replace("[Skill Weightages]", skiwei)
        response_cv = get_result_from_omni(system_message, combined_text_CV)
        response_cv = ast.literal_eval(response_cv)
        print(response_cv)
        print(type(response_cv))
        if isinstance(response_cv, str):
            try:
                response_cv = json.loads(response_cv)  # Ensure it's properly parsed
            except json.JSONDecodeError:
                return jsonify({"error": "Invalid response format from the ranking system."}), 500

        if not isinstance(response_cv, list):
            return jsonify({"error": "Unexpected response format"}), 500
        return jsonify(response_cv)

    except ValueError as ve:
        return jsonify({"error": str(ve)}), 500