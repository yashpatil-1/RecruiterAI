from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from reportlab.lib.units import inch
from reportlab.lib.utils import ImageReader
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
import os
from io import BytesIO
from variable_loader import font_folder_path ,font_name
from src.gpt_utilities import get_completion
from flask import Blueprint, request, jsonify,send_file

jd_maker_bp = Blueprint('jd_maker_bp', __name__)

@jd_maker_bp.route('/generate_job_description', methods=['POST'])
def generate_job_description():
    try:
        print("Inside JD Generator")
        user_inputs = request.form.to_dict()
        # if not user_inputs:
        #     return jsonify({"status": "error", "message": "No data provided. Please fill out the form."}), 400

        # Validate required fields
        required_fields = ["location", "ename", "d-level", "LOS", "techsk", "yexp", "mname", "language"]
        for field in required_fields:
            if not user_inputs.get(field):
                return jsonify({"status": "error", "message": f"{field.replace('-', ' ').title()} is required."}), 400
        
        # Specific validation for Years of Experience
        if not user_inputs.get("yexp").isdigit():
            return jsonify({"status": "error", "message": "Years of experience must be a number."}), 400


        print(user_inputs)
        font_size=17
        prompt = f"""
        You are a recruiter of RecruiterAI. Create a job description using the following information\
        {user_inputs}
        Keep it detailed. Have a professional tone. Do not have any\
        redundancy in the job description.

        Example of a Job description of a Senior Manager in Cybersecurity, Privacy and Forensics: 
        Job Title Responsible AI (RAI) - Senior Manager
        Job Category Cybersecurity, Privacy and Forensics
        Level Senior Manager
        Specialty/Competency Forensic Technology
        Industry/Sector Not Applicable
        Job Type Regular
        Time Type Full time
        Location(s) MA-Boston, NY-New York

        A career in our Cybersecurity, Privacy and Forensics will provide you the opportunity to solve our clients most critical business and data protection related challenges. You will be part of a growing team driving strategic programs, data analytics, innovation, deals, cyber resilency, response, and technical implementation activities. You will have access to not only the top Cybersecurity, Privacy and Forensics professionals at XYZ Company, but at our clients and industry analysts across the globe. Our Information Governance team focuses on helping our clients protect their business in today’s evolving landscape by applying advanced and strategic approaches to information management. We focus on assisting organisations manage vast amounts of electronic data and navigate the legal and business processes demanded by critical events, which includes litigation, regulatory requests and internal investigations. Our team helps our clients understand their current capabilities and assist in the implementation of governance controls to effectively mitigate information risk and maximise exploitation of their information assets.

        To really stand out and make us fit for the future in a constantly changing world, each and every one of us at XYZ Company needs to be an authentic and inclusive leader, at all grades/levels and in all lines of service. To help us achieve this we have the XYZ Company Professional; our global leadership development framework. It gives us a single set of expectations across our lines, geographies and career paths, and provides transparency on the skills we need as individuals to be successful and progress in our careers, now and in the future.

        As a Senior Manager, you'll work as part of a team of problem solvers, helping to solve complex business issues from strategy to execution. XYZ Company Professional skills and responsibilities for this management level include but are not limited to:

        Take action to ensure everyone has a voice, inviting opinion from all.
        Establish the root causes of issues and tackle them, rather than just the symptoms.
        Initiate open and honest coaching conversations at all levels.
        Move easily between big picture thinking and managing relevant detail.
        Anticipate stakeholder needs, and develop and discuss potential solutions, even before the stakeholder realises they are required.
        Develop specialised expertise in one or more areas.
        Advise stakeholders on relevant technical issues for their business area.
        Navigate the complexities of global teams and engagements.
        Build trust with teams and stakeholders through open and honest conversation.
        Uphold the firm's code of ethics and business conduct.
        Job Requirements and Preferences:

        Basic Qualifications:

        Minimum Degree Required:
        Bachelor Degree

        Minimum Years of Experience:
        7 year(s)

        Preferred Qualifications:

        Preferred Fields of Study:
        Computer and Information Science, Computer Engineering, Information Technology, Management Information Systems

        Preferred Knowledge/Skills:

        Demonstrates intimate-level abilities and/or a proven record of success managing efforts with identifying and addressing client needs including:

        Lead and manage client projects focused on Responsible AI (RAI) with guidance and feedback from team senior members;
        Engage in high-level strategic thinking and problem solving to build actionable and practical AI risk management frameworks and processes for large clients;
        Articulate complex Responsible AI concepts in a clear and compelling manner, crafting narratives that resonate with executive audiences;
        Facilitate workshops and training sessions, employing storytelling to make complex ideas accessible and engaging;
        Lead high performing teams and contribute to the development of RAI experience and expertise among junior team members;
        Contribute to thought leadership in the field of Responsible AI, influencing both internal and external discourse; 
        Possess 10 years of experience in management consulting, with a focus on strategic thinking and problem structuring in risk management, governance, and technology topics;
        Possess foundational understanding and high degree of comfort with basic technical AI, GenAI and machine learning concepts and how these can be translated to business strategies;
        Demonstrate proven communication skills, with proficiency in executive-level storytelling and presenting complex ideas in a clear, concise manner;
        Operate in a fast-paced project environment with evolving client needs and project objectives;
        Possess qualitative analytical skills, adept at synthesizing diverse information into coherent and actionable insights;
        Needs curiosity and a commitment to continuous learning in the evolving field of Responsible AI;
        Supervise teams to create an atmosphere of trust and seeking diverse views to encourage improvement and innovation;
        Responsible for answering questions and providing direction to less-experienced staff; coaching staff including providing timely meaningful written and verbal feedback;
        Possess experience in AI systems, AI ethics, policy, or related areas;
        Utilize experience in quantitative modeling, software development and data science;
        Certifications in risk management or AI-related fields; and,
        Demonstrate published work or public speaking experience on Responsible AI.
        Learn more about XYZ Company India: https://XYZ Company.in 

        All qualified applicants will receive consideration for employment at XYZ Company without regard to race; creed; color; religion; national origin; sex; age; disability; sexual orientation; gender identity or expression; genetic predisposition or carrier status; veteran, marital, or citizenship status; or any other status protected by law. XYZ Company is proud to be an affirmative action and equal opportunity employer.

        Use the above format to build the JD. Keep the preferred skills detailed by considering all parent and child skills required.
        """
        # if language.strip()=="English":
        if not font_folder_path or not font_name:
            return jsonify({"status": "error", "message": "Font path or font name is not configured properly."}), 500
        try:
            packet = BytesIO()
            can = canvas.Canvas(packet, pagesize=letter)
            page_width, page_height = letter
            page_width -= 2*inch
            font_path = os.path.join(font_folder_path,font_name+".ttf")
            pdfmetrics.registerFont(TTFont(font_name, font_path))
            can.setFont(font_name, font_size)
            try:
                response = get_completion("You are a Job description generator.", prompt)
            except Exception as e:
                return jsonify({"status": "error", "message": f"Error generating job description: {str(e)}"}), 500
            
       
            cleaned_response = response.replace('**', '')
            # print(cleaned_response)
            pdfcontent=cleaned_response
            lines = pdfcontent.split('\n')
            x = 50
            y = page_height - inch-40
            line_height = 14
            image_path = 'static/jd.png'
            image = ImageReader(image_path)
            can.setFont(font_name, font_size)
            can.drawImage(image, 0, page_height-inch-30, width=page_width+2*inch, height=100)
            for line in lines:
                words = line.split()
                current_line = ""
                for word in words:
                    new_line = current_line + word + " "
                    line_width = can.stringWidth(new_line, font_name, 15)
                    if line_width <= page_width:
                        current_line = new_line
                    else:
                        can.setFont(font_name, font_size)
                        can.drawString(x, y, current_line)
                        y -= line_height
                        if y <= inch:
                            can.showPage()
                            y = page_height - inch-40
                            can.drawImage(image, 0, page_height-inch-30, width=page_width+2*inch, height=100)
                        current_line = word + " "
                can.setFont(font_name, font_size)
                can.drawString(x, y, current_line)
                y -= line_height
                if y <= inch:
                    can.showPage()
                    can.setFont(font_name, font_size)
                    y = page_height - inch-40
                    can.drawImage(image, 0, page_height-inch-30, width=page_width+2*inch, height=100)
            can.save()
            packet.seek(0)
            return send_file(packet, mimetype='application/pdf', as_attachment=True, download_name= "Job_Description.pdf")
        except Exception as e:
            return jsonify({"status": "error", "message": f"Error creating PDF: {str(e)}"}), 500
    except Exception as e:
        return jsonify({"status": "error", "message": f"Unexpected error: {str(e)}"}), 500