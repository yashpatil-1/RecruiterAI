// Start interview function
function start_interview(cvURL, jdFile) {
  console.log("Interview started with CV:", cvURL);
  console.log("Starting interview with CV:", cvURL, " and JD:", jdFile);
  // Redirect or trigger the interview page or action
  window.location.href = '/interview'; // Assuming /interview is the interview page
}

document.addEventListener("DOMContentLoaded", function () {
  const dropbox = document.getElementById("dropbox");
  const dropbox_jd = document.getElementById("dropbox-jd");
  const fileInput = document.getElementById("file-input");
  const fileInput_jd = document.getElementById("file-input-jd");
  const textForm = document.getElementById("ask"); //text-form
  const analyse_loader = document.getElementById("analyse-loader");
  const analyse = document.getElementById("analyse");
  const conversationContainer = document.getElementById("conversation-container");
  const skills_container = document.getElementById('skills-container');
  const skill_loader = document.getElementById('skill-loader');
  const skill_output = document.getElementById('skill-output');
  const analyse_output = document.getElementById('analyse_output');
  const name_CVs = document.getElementById('name_CVs');
  const name_JD = document.getElementById('name_JD');
  const excelDownloadLink = document.getElementById('excelDownloadLink');
  const interact_section = document.getElementById('interact_section');
  let total = 0;
  let parsedRankingData = [];

  // Helper function for displaying messages
  function displayMessage(type, message) {
    let toastContainer = document.getElementById("toast-container");
    if (!toastContainer) {
      toastContainer = document.createElement("div");
      toastContainer.id = "toast-container";
      document.body.appendChild(toastContainer);
    }

    const toast = document.createElement("div");
    toast.classList.add("toast", type === "success" ? "toast-success" : "toast-error");
    toast.innerText = message;

    toastContainer.appendChild(toast);

    setTimeout(() => {
      toast.classList.add("fade-out");
      setTimeout(() => {
        toast.remove();
      }, 500);
    }, 5000);
  }

    // File validation helper function
    function isValidPDF(file) {
      return file && file.type === 'application/pdf';
    }
    

  // Drag-and-drop event listeners
  function setupDropbox(dropbox, fileInput, nameDisplay, singleFile = false) {
    dropbox.addEventListener("dragenter", (e) => {
      e.preventDefault();
      dropbox.classList.add("dragover");
    });
    dropbox.addEventListener("dragover", (e) => {
      e.preventDefault();
      dropbox.classList.add("dragover");
    });
    dropbox.addEventListener("dragleave", (e) => {
      e.preventDefault();
      dropbox.classList.remove("dragover");
    });
    dropbox.addEventListener("drop", (e) => {
      e.preventDefault();
      dropbox.classList.remove("dragover");
      const files = e.dataTransfer.files;
      if (files.length > 0) {
        if (!isValidPDF(files[0])) {
          displayMessage('error', 'Please upload a valid PDF file.');
          return;
        }
        if (singleFile && files.length > 1) {
          displayMessage('error', 'Only one file allowed for Job Description.');
        } else {
          fileInput.files = files;
          nameDisplay.style.display = 'block';
          nameDisplay.innerHTML = files.length + (singleFile ? " file" : " CV(s)") + " uploaded";
        }
      }
    });
  }

  setupDropbox(dropbox, fileInput, name_CVs);
  setupDropbox(dropbox_jd, fileInput_jd, name_JD, true);

  dropbox.addEventListener("click", () => fileInput.click());
  dropbox_jd.addEventListener("click", () => fileInput_jd.click());

  fileInput.addEventListener("change", function (event) {
    const selectedFiles = event.target.files;
    for (let i = 0; i < selectedFiles.length; i++) {

      if (!isValidPDF(selectedFiles[i])) {

        displayMessage("error", "Invalid file format. Please upload a PDF file.");

        fileInput.value = '';  // Clear the invalid files

        return;

      }

    }
    name_CVs.style.display = 'block';
    name_CVs.innerHTML = selectedFiles.length + " CV(s) uploaded";
  });

  // Handle skills and weightages extraction
  var skillslist = [], weightagelist = [];
  let formattedContent;
  fileInput_jd.addEventListener("change", function (event) {
    const selectedFile = event.target.files[0];

    if (!isValidPDF(selectedFile)) {

      displayMessage("error", "Invalid file format. Please upload a PDF file.");

      fileInput_jd.value = '';  // Clear the invalid file

      return;

    }

    skillslist = [];
    weightagelist = [];
    skills_container.style.display = "block";
    skill_loader.style.display = "inline-flex";
    // const selectedFile = event.target.files[0];
    skill_output.innerHTML = "<br>";
    name_JD.style.display = 'block';
    name_JD.innerHTML = selectedFile.name.split(".")[0];

    const formData = new FormData();
    formData.append("pdf_file_JD", selectedFile);

    const xhr = new XMLHttpRequest();
    xhr.open("POST", "/cv_analyzer/get_skills_and_weightages", true);
    xhr.onreadystatechange = function () {
      if (xhr.readyState === XMLHttpRequest.DONE) {
        skill_loader.style.display = "none";
        if (xhr.status === 200) {
          try {
            const response = JSON.parse(xhr.responseText.trim());
            const parsedData = JSON.parse(response);

            parsedData.forEach(item => {
              if (Array.isArray(item) && item.length === 2) {
                skillslist.push(item[0]);
                weightagelist.push(item[1]);
              }
            });

            displaySkillsAndWeightages();
          } catch (err) {
            displayMessage("error", "Error parsing skills and weightages.");
            console.error(err);
          }
        } else {
          displayMessage("error", "Failed to retrieve skills and weightages.");
        }
      }
    };
    xhr.onerror = function () {
      skill_loader.style.display = "none";
      displayMessage("error", "Error occurred while extracting skills.");
    };
    xhr.send(formData);
  });

  function displaySkillsAndWeightages() {
    formattedContent = document.createElement("table");
    total = 100;  // Initialize total weightage to 100

    for (let i = 0; i < skillslist.length; i++) {
      const row = formattedContent.insertRow();
      let skillCell = row.insertCell(0);
      let weightageCell = row.insertCell(1);

      if (i === 0) {
        skillCell.innerHTML = skillslist[i];
        weightageCell.innerHTML = weightagelist[i];
      } else {
        skillCell.innerHTML = `<input type='text' value='${skillslist[i]}' style='background-color: #252525; color: white; width: 400px;' />`;
        weightageCell.innerHTML = `<input type='text' value='${weightagelist[i]}' style='background-color: #252525; color: white; width: 80px;' class='weightage' />`;
        let deleteCell = row.insertCell(2);
        deleteCell.innerHTML = `<button onclick='deleteRow(this)' style='background-color: #ff4c4c; color: white;'>-</button>`;
      }
    }

    let addButton = document.createElement('button');
    addButton.innerHTML = '+';
    addButton.style = 'background-color: #4CAF50; color: white; padding: 5px; margin-top: 10px; width: 40px;';
    addButton.onclick = function () {
      let newRow = formattedContent.insertRow();
      newRow.insertCell(0).innerHTML = `<input type='text' style='background-color: #252525; color: white; width: 400px;' />`;
      newRow.insertCell(1).innerHTML = `<input type='text' style='background-color: #252525; color: white; width: 80px;' class='weightage' />`;
      newRow.insertCell(2).innerHTML = `<button onclick='deleteRow(this)' style='background-color: #ff4c4c; color: white;'>-</button>`;
      bindWeightageInputListeners();
    };

    skill_output.appendChild(formattedContent);
    skill_output.appendChild(addButton);
    bindWeightageInputListeners();
    updateTotalWeightage();
  }

  // Handle Analyse Button
  analyse.addEventListener("click", function () {
    if (fileInput.files.length > 0 && fileInput_jd.files.length > 0) {
      if (total !== 100) {
        displayMessage("error", "Total weightage should be 100%.");
        return;
      } else {
        analyse.disabled = true;
        fileInput.disabled = true;
        fileInput_jd.disabled = true;
        interact_section.style.display = 'none';
        analyse_loader.style.display = "inline-flex";

        const formData = new FormData();
        for (let i = 0; i < fileInput.files.length; i++) {
          formData.append("pdf_files_CV", fileInput.files[i]);
        }

        const updated_skills = [];
        const updated_weights = [];

        const tableRows = formattedContent.rows;
        for (let j = 0; j < tableRows.length; j++) {
          const skillInput = tableRows[j].cells[0].querySelector('input');
          const weightageInput = tableRows[j].cells[1].querySelector('input');

          updated_skills.push(skillInput ? skillInput.value : tableRows[j].cells[0].textContent.trim());
          updated_weights.push(weightageInput ? weightageInput.value : tableRows[j].cells[1].textContent.trim());
        }

        formData.append("skills", updated_skills.join("@"));
        formData.append("weightages", updated_weights);

        const xhr = new XMLHttpRequest();
        xhr.open("POST", "/cv_analyzer/generate_ranking", true);
        xhr.onreadystatechange = function () {
          if (xhr.readyState === XMLHttpRequest.DONE) {
            analyse.disabled = false;
            analyse_loader.style.display = "none";
            if (xhr.status === 200) {
              try {
                parsedRankingData = JSON.parse(xhr.responseText.trim());
                displayRanking(parsedRankingData);
                displayMessage("success", "Ranking data parsed.");
              } catch (err) {
                displayMessage("error", "Failed to parse ranking data.");
              }
            } else {
              displayMessage("error", "Error generating rankings.");
            }
          }
        };
        xhr.onerror = function () {
          analyse.disabled = false;
          analyse_loader.style.display = "none";
          displayMessage("error", "Error occurred while generating rankings.");
        };
        xhr.send(formData);
      }
    } else {
      displayMessage("error", "Please upload both CVs and a Job Description.");
    }
  });

  function displayRanking(parsedData) {
    // 1. Get reference to the <tbody> (defined in HTML)
    const rankingTableBody = document.getElementById("rankingTableBody");
    console.log(parsedData);
    console.log(typeof(parsedData));
    // 2. Clear any old rows
    rankingTableBody.innerHTML = "";
  
    // (Optional) Check for length mismatch if needed
    if (parsedData.length !== fileInput.files.length) {
      const tr = document.createElement("tr");
      tr.style.border = "1px solid white";
      const nameCell = document.createElement("td");
      nameCell.textContent ="No match found";
      tr.appendChild(nameCell);
      const scoreCell = document.createElement("td");
      scoreCell.textContent ="-";
      tr.appendChild(scoreCell);
      const interviewCell = document.createElement("td");
      interviewCell.textContent ="-";
      tr.appendChild(interviewCell);
      rankingTableBody.appendChild(tr);
      interact_section.style.display = "block";
      console.error(
        `Mismatch: parsedData has ${parsedData.length} items, but you uploaded ${fileInput.files.length} files.`
      );
      return;
    }
  
    // 3. Loop over parsedData, create a row, and append to <tbody>
    for (let i = 0; i < parsedData.length; i++) {
      const row = parsedData[i]; 
      const file = fileInput.files[i];
      const fileURL = URL.createObjectURL(file);
  
      // row might look like:
      // [
      //   'Alex Johnson',              // Name
      //   '85/100',                    // Score
      //   'alex.johnson@email.com',    // Email
      //   '(555) 123-4567',           // Phone
      //   'Skill1 Score, Skill2...',   // Skill string
      //   '4'                          // Experience
      // ]
  
      // Create a <tr>
      const tr = document.createElement("tr");
      tr.style.border = "1px solid white";
  
      // 3a. Candidate name as link
      const nameCell = document.createElement("td");
      const link = document.createElement("a");
      link.href = fileURL;
      link.target = "_blank";
      link.textContent = row[0];
      nameCell.appendChild(link);
      tr.appendChild(nameCell);
  
      // 3b. Score cell
      const scoreCell = document.createElement("td");
      scoreCell.textContent = row[1];
      tr.appendChild(scoreCell);
  
      // 3c. Interview cell with button
      const interviewCell = document.createElement("td");
      const interviewButton = document.createElement("button");
      interviewButton.textContent = "Interview Now!";
      interviewButton.onclick = () => start_interview(fileURL, fileInput_jd.files[0].name);
      interviewCell.appendChild(interviewButton);
      tr.appendChild(interviewCell);
  
      // 3d. Finally, add this <tr> to <tbody>
      rankingTableBody.appendChild(tr);
    }
  
    // 4. Make the section visible
    interact_section.style.display = "block";
  }
  excelDownloadLink.addEventListener('click', function () {
    if (parsedRankingData.length > 0) {
      const headers = ['Employee Name', 'Score', 'Email-ID', 'Contact No.', 'Score Given to Skills', 'Experience'];
      const worksheetData = [headers, ...parsedRankingData];

      const workbook = XLSX.utils.book_new();
      const worksheet = XLSX.utils.aoa_to_sheet(worksheetData);
      XLSX.utils.book_append_sheet(workbook, worksheet, "Sheet1");

      const today = new Date();
      const formattedDate = `${String(today.getDate()).padStart(2, '0')}/${String(today.getMonth() + 1).padStart(2, '0')}/${today.getFullYear()}`;
      XLSX.writeFile(workbook, 'CV_Ranking_' + formattedDate + '.xlsx');
      displayMessage("success", "Ranking data downloaded.");
    } else {
      displayMessage("error", "No data available for download.");
    }
  });

  // Total weightage update function
  function updateTotalWeightage() {
    const weightageInputs = document.querySelectorAll('.weightage');
    total = Array.from(weightageInputs).reduce((acc, input) => acc + (parseInt(input.value) || 0), 0);
    document.getElementById('total-weightage').textContent = total;
    document.getElementById('total-weightage').style.color = total === 100 ? "green" : "red";
  }

  // Bind weightage input listeners
  function bindWeightageInputListeners() {
    const weightageInputs = document.querySelectorAll('.weightage');
    weightageInputs.forEach(input => input.addEventListener('input', updateTotalWeightage));
  }

  function deleteRow(button) {
    const row = button.closest('tr');
    row.remove();
    updateTotalWeightage();
  }

  // Handle submit for text questions
  const submitBtn_1 = document.getElementById("submit-btn-cv");
  const inputTextContainer = document.getElementById("ask");
  const submitLoader = document.getElementById("submit-loader");

  textForm.addEventListener("keydown", function (event) {
    if (event.keyCode === 13) {
      event.preventDefault();
      submitBtn_1.click();
    }
  });
});
